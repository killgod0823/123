package com.shs.dao;


import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.shs.pojo.Admin;
import com.shs.pojo.Messages;
import com.shs.pojo.Student;
import com.shs.pojo.Teacher;
import com.shs.utils.DBUtil;

public class AdminDaoImpl implements AdminDao {

	@Override
	public int AddStudent(Student student) throws SQLException {
		// TODO Auto-generated method stub
		System.out.println("dao:"+student);
		int rs1;
		int rs2;
		DBUtil dbUtil=new DBUtil();
		String sql="insert into s_student(name,password,studentId) values(?,?,?)";
		String sql2="insert into studentinfo(studentId,name,sex,age,clazz) values(?,?,?,?,?)";
		PreparedStatement ps=dbUtil.getPreparedStatement(sql);
		PreparedStatement ps2=dbUtil.getPreparedStatement(sql2);
		
		ps.setString(1, student.getName());
		ps.setString(2, student.getPassword());
		ps.setString(3, student.getStudentId());
		
		
		ps2.setString(1, student.getStudentId());
		ps2.setString(2, student.getName());
		ps2.setString(3, student.getSex());
		ps2.setInt(4, student.getAge());
		ps2.setString(5, student.getClazz());
		
		
		
		rs1=ps.executeUpdate();
		rs2=ps2.executeUpdate();
		if(rs1==1&&rs2==1) {
			return 1;
		}else {
			return 0;
		}
		
	}

	@Override
	public int AddTeacher(Teacher teacher) throws SQLException {
		// TODO Auto-generated method stub
		System.out.println("dao:"+teacher);
		int rs1;
		int rs2;
		DBUtil dbUtil=new DBUtil();
		String sql="insert into s_teacher(name,password,teacherId) values(?,?,?)";
		//插入数据的时候使用insert ignore ，保证已有记录便不再插入
		String sql2="insert  into teacherinfo(teacherId,tname,tsex,tage,tdept,tel,QQ,professional) values(?,?,?,?,?,?,?,?)";
		PreparedStatement ps=dbUtil.getPreparedStatement(sql);
		PreparedStatement ps2=dbUtil.getPreparedStatement(sql2);
		
		
		ps.setString(1, teacher.getTname());
		ps.setString(2, teacher.getPassword());
		ps.setString(3, teacher.getTeacherId());
		
		ps2.setString(1, teacher.getTeacherId());
		ps2.setString(2, teacher.getTname());
		ps2.setString(3, teacher.getTsex());
		ps2.setString(4, teacher.getTage());
		ps2.setString(5, teacher.getTdept());
		ps2.setString(6, teacher.getTel());
		ps2.setString(7, teacher.getQQ());
		ps2.setString(8, teacher.getProfessional());
		
		
		/*//数据更新*/		
		rs1=ps.executeUpdate();
		rs2=ps2.executeUpdate();
		
		if(rs1==1&&rs2==1) {		
			return 1;
		}else {
			return 0;
		}
	
	}

	@Override
	public int AddAdmin(Admin admin) throws SQLException {
		
		int rs1;
		
		DBUtil dbUtil=new DBUtil();
		String sql="insert into s_admin(name,password) values(?,?)";
		
		PreparedStatement ps=dbUtil.getPreparedStatement(sql);
		
		
		ps.setString(1, admin.getName());
		ps.setString(2, admin.getPassword());

		rs1=ps.executeUpdate();
		
		if(rs1==1) {
			return 1;
		}else {
			return 0;
		}
		
	}
	//
	@Override
	public int AddMessages(Messages messages) throws SQLException {
		// TODO Auto-generated method stub
		
        int rs1;
		
		DBUtil dbUtil=new DBUtil();
		String sql="insert into s_messages(name,title,message) values(?,?,?)";
		
		PreparedStatement ps=dbUtil.getPreparedStatement(sql);
		
		ps.setString(1, messages.getName());
		ps.setString(2, messages.getTitle());
		ps.setString(3, messages.getMessages());

		rs1=ps.executeUpdate();
		System.out.print("dao:" + messages);
		
		if(rs1==1) {
			//dbUtil.commit();
			return 1;
		}else {
			return 0;
		}
	}

}
