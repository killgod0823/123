package com.shs.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.shs.pojo.Student;
import com.shs.utils.DBUtil;

public class StudentDaoImpl implements StudentDao {

	@Override
	public int ifhasTitle(String studentId) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil=new DBUtil();
		String sql="select titleId from studentinfo where studentId=?";
		PreparedStatement ps=(PreparedStatement) dbUtil.getPreparedStatement(sql);
		
		ps.setString(1,studentId);
	
		ResultSet rs=ps.executeQuery();
		
		while(rs.next()) {
			
			return rs.getInt("titleId");
            
		}

		return 0;
	}
    //选题
	@Override
	public int chooseTitle(String studentId, String teacherId, int titleId) throws SQLException {
		// TODO Auto-generated method stub
        DBUtil dbUtil=new DBUtil();
		
		String sql="update studentinfo set titleId=? ,teacherId=? where studentId=?";
		
		PreparedStatement ps=(PreparedStatement) dbUtil.getPreparedStatement(sql);
		
		ps.setInt(1, titleId);
		ps.setString(2,teacherId);
		ps.setString(3, studentId);
		
		int rs1=ps.executeUpdate();
		
        if (rs1==1) {
        	
				return 1;
			}else {
				
				return 0;
			}
	}
    //选题退选
	@Override
	public int delTitle(String studentId, String teacherId, int titleId) throws SQLException {
		// TODO Auto-generated method stub
         DBUtil dbUtil=new DBUtil();
		
		String sql="update studentinfo set titleId=0 ,teacherId='无 ' where studentId=?";
		
		PreparedStatement ps=(PreparedStatement) dbUtil.getPreparedStatement(sql);
		
		
		ps.setString(1, studentId);
		
		int rs1=ps.executeUpdate();
		
        if (rs1==1) {
        	
				return 1;
			}else {
				
				return 0;
			}
	}
     //选题题目
	@Override
	public String getTname(int titleId) throws SQLException {
		// TODO Auto-generated method stub
      DBUtil dbUtil=new DBUtil();
		
		String sql="select name from titleinfo  where titleId=?";
		
		PreparedStatement ps=(PreparedStatement) dbUtil.getPreparedStatement(sql);
		
		
		ps.setInt(1, titleId);
		
		ResultSet rs1=ps.executeQuery();
		
        if (rs1.next()) {
        	
				return rs1.getString("titleId");
			}else {
				
				return null;
			}
	}
//作品上传
	@Override
	public int submitMyProject(String studentId, String src) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil=new DBUtil();
		
		String sql="update studentinfo set src=? where studentId=?";
		
		PreparedStatement ps=(PreparedStatement) dbUtil.getPreparedStatement(sql);
		
		
		ps.setString(1, src);
		ps.setString(2, studentId);
		int rs1=ps.executeUpdate();
		
        if (rs1==1) {
        	
				return 1;
			}else {
				
				return 0;
			}
	}

	@Override
	public int delstudent(String studentId) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil=new DBUtil();
		
		String sql="delete from studentinfo  where studentId=?";
		String sql2="delete from s_student where studentId=?";
		PreparedStatement ps1=(PreparedStatement) dbUtil.getPreparedStatement(sql);
		PreparedStatement ps2=(PreparedStatement) dbUtil.getPreparedStatement(sql2);
		
		ps1.setString(1, studentId);
		ps2.setString(1, studentId);
		int rs1=ps1.executeUpdate();
		int rs2=ps2.executeUpdate();
        if (rs1==1&&rs2==1) {
        	
				return 1;
			}else {
				
				return 0;
			}
		
	}
	
	
}
