package com.shs.dao;

import java.sql.SQLException;
import java.util.List;


import com.shs.pojo.Messages;
import com.shs.pojo.Student;
import com.shs.pojo.Title;

public interface TeacherDao {
     public int addTitle(Title title) throws SQLException;
     public List<Object> selectMyStudentList(String page,String limit,String teacherId) throws SQLException;
     public int countMyStudent(String teacherId) throws SQLException;
     public int editGrade(Student student) throws SQLException;
     public int delteacher(String teacherId)throws SQLException;
}
