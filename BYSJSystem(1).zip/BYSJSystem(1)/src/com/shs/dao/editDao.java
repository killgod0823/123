package com.shs.dao;

import java.sql.SQLException;

import com.shs.pojo.Student;
import com.shs.pojo.Teacher;

public interface editDao {
	public int EditTeacher(Teacher teacher)throws SQLException;
	public int EditStudent(Student student)throws SQLException;

}
