package com.shs.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.cj.protocol.Message;
import com.shs.pojo.Student;
import com.shs.pojo.Teacher;
import com.shs.pojo.Title;
import com.shs.utils.DBUtil;
import com.shs.pojo.Messages;;

public class TeacherDaoImpl implements TeacherDao {
   //添加课题
	@Override
	public int addTitle(Title title) throws SQLException {
		// TODO Auto-generated method stub
        DBUtil dbUtil=new DBUtil();
		
		String sql="insert into titleinfo(type,name,src,teacherId) values(?,?,?,?)";
		
		PreparedStatement ps=(PreparedStatement) dbUtil.getPreparedStatement(sql);
		
		ps.setString(1, title.getType());
		ps.setString(2, title.getName());
		ps.setString(3, title.getSrc());
		ps.setString(4, title.getTeacherId());
		
		int rs1=ps.executeUpdate();
		System.out.println(rs1);
		
        if (rs1==1) {
        	
				return 1;
			}else {
				
				return 0;
			}
			
		
	}
    //根据教师id查询出对应选题的学生
	@Override
	public List<Object> selectMyStudentList(String page, String limit, String teacherId) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil=new DBUtil();
		String sql="select * from studentinfo where teacherId=? limit ?,?";
		PreparedStatement ps=(PreparedStatement) dbUtil.getPreparedStatement(sql);
		int page1=Integer.parseInt(page);
		int limit1=Integer.parseInt(limit);
		ps.setString(1, teacherId);
		ps.setInt(2, (page1-1)*limit1);
		ps.setInt(3, limit1);
		ResultSet rs=ps.executeQuery();
		 List<Object> list=new ArrayList<Object>();
		while(rs.next()) {
			
			Student s = new Student();

             s.setStudentId(rs.getString("studentId"));
             s.setName(rs.getString("name"));
             s.setAge(rs.getInt("age"));
             s.setSex(rs.getString("sex"));
             s.setTitleId( rs.getInt("titleId"));
             s.setTeacherId( rs.getString("teacherId"));
             s.setGrade(rs.getInt("grade"));
             //System.out.println(s);
             list.add(s);
		}
		
		return list;
	}
    //统计我的学生的数量
	@Override
	public int countMyStudent(String teacherId) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil=new DBUtil();
		 String sql="select count(*) as sum from studentinfo  where teacherId=?"; 
		 PreparedStatement ps=(PreparedStatement) dbUtil.getPreparedStatement(sql);
		 ps.setString(1, teacherId);
		ResultSet rs=ps.executeQuery();	
		
		while(rs.next()) {
			
			return rs.getInt("sum");
		}
		return 0;
	}
    //教师编辑学生成绩
	@Override
	public int editGrade(Student student) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil=new DBUtil();
		String sql="update studentinfo set grade=?  where studentId=?";
		PreparedStatement ps=(PreparedStatement) dbUtil.getPreparedStatement(sql);
		ps.setInt(1, student.getGrade());
		ps.setString(2,student.getStudentId());
		int rs=ps.executeUpdate();
		while(rs==1) {
			
			return 1;
		}
		
		return 0;
	}
    //删除教师
	@Override
	public int delteacher(String teacherId) throws SQLException {
		// TODO Auto-generated method stub
        DBUtil dbUtil=new DBUtil();
		
		String sql="delete from teacherinfo  where teacherId=?";
		String sql2="delete from s_teacher  where teacherId=?";
		PreparedStatement ps=(PreparedStatement) dbUtil.getPreparedStatement(sql);
		PreparedStatement ps2=(PreparedStatement) dbUtil.getPreparedStatement(sql2);
		int id=Integer.parseInt(teacherId);
		ps.setString(1, teacherId);
	

	ps2.setInt(1,id);
		int rs1=ps.executeUpdate();
		int rs2=ps2.executeUpdate();
		 if (rs1==1&&rs2==1) {
        		return 1;
        					
			}else {
				
				return 0;
			}
		
		
	}
	
}
