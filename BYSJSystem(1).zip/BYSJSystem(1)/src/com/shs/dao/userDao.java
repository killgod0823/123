package com.shs.dao;

import java.sql.SQLException;
import java.util.List;

import com.shs.controller.AddAdmin;
import com.shs.pojo.Admin;
import com.shs.pojo.Student;
import com.shs.pojo.Teacher;

public interface userDao {
     public Admin selectALlAdmin(String name,String password) throws SQLException;
     public Student selectALlStudent(String name,String password)throws SQLException;
     public Teacher selectALlTeacher(String name,String password)throws SQLException;
     public List<Object> selectTeacherList() throws SQLException;
     public List<Object> selectStudentList() throws SQLException;
     public List<Object> selectTeacherList(String page,String limit) throws SQLException;
     public List<Object> selectTitleList(String page,String limit) throws SQLException;
     public List<Object> selectTitleList2(String name) throws SQLException;
     public int countTeacher() throws SQLException;
     public int addStudent(Student student)throws SQLException;
     public int addTeacher(Teacher teacher)throws SQLException;
     public int addAdmin(Admin admin)throws SQLException;
     
}
