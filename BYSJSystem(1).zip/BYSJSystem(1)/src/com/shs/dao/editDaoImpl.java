 package com.shs.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.shs.pojo.Admin;
import com.shs.pojo.Student;
import com.shs.pojo.Teacher;
import com.shs.utils.DBUtil;

public class editDaoImpl implements editDao {

	@Override
	public int EditTeacher(Teacher teacher) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil=new DBUtil();
		String sql="update teacherinfo set tname=?,tage=?,tsex=?,tdept=?,tel=?,QQ=?,professional=?  where teacherId=?";
		PreparedStatement ps=(PreparedStatement) dbUtil.getPreparedStatement(sql);
		ps.setString(1, teacher.getTname());
		ps.setString(2, teacher.getTage());
		ps.setString(3, teacher.getTsex());
		ps.setString(4, teacher.getTdept());
		ps.setString(5, teacher.getTel());
		ps.setString(6, teacher.getQQ());
		ps.setString(7, teacher.getProfessional());
		ps.setString(8, teacher.getTeacherId());
		int rs=ps.executeUpdate();
		while(rs==1) {
			
			return 1;
		}
		
		return 0;
	}

	@Override
	public int EditStudent(Student student) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil=new DBUtil();
		String sql="update studentinfo set name=?,age=?,sex=?,teacherId=?,grade=?,clazz=?,titleId=?  where studentId=?";
		PreparedStatement ps=(PreparedStatement) dbUtil.getPreparedStatement(sql);
		ps.setString(1, student.getName());
		ps.setInt(2, student.getAge());
		ps.setString(3, student.getSex());
		ps.setString(4, student.getTeacherId());
		ps.setInt(5, student.getGrade());
		ps.setString(6, student.getClazz());
		ps.setInt(7, student.getTitleId());
		ps.setString(8,student.getStudentId());
		int rs=ps.executeUpdate();
		while(rs==1) {
			
			return 1;
		}
		
		return 0;
	}
}