package com.shs.dao;

import java.sql.SQLException;

public interface StudentDao {
    public int ifhasTitle(String studentId) throws SQLException;
    public int chooseTitle(String studentId,String teacherId,int titleId) throws SQLException;
    public int delTitle(String studentId,String teacherId,int titleId) throws SQLException;
    public String getTname(int titleId) throws SQLException;
    
    public int submitMyProject(String studentId,String src) throws SQLException;
    public int delstudent(String studentId)throws SQLException;
    
    
}
