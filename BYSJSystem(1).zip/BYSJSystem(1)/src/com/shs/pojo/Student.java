package com.shs.pojo;




public class Student {
  private String studentId;
  private String name;
  private String password;
  private String sex;
  private int age;
  private String teacherId;
  private int grade;
  private String clazz;
  private int titleId;
  private String src;
public String getStudentId() {
	return studentId;
}
public void setStudentId(String studentId) {
	this.studentId = studentId;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getSex() {
	return sex;
}
public void setSex(String sex) {
	this.sex = sex;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getTeacherId() {
	return teacherId;
}
public void setTeacherId(String teacherId) {
	this.teacherId = teacherId;
}
public int getGrade() {
	return grade;
}
public void setGrade(int grade) {
	this.grade = grade;
}
public String getClazz() {
	return clazz;
}
public void setClazz(String clazz) {
	this.clazz = clazz;
}
public int getTitleId() {
	return titleId;
}
public void setTitleId(int titleId) {
	this.titleId = titleId;
}
public String getSrc() {
	return src;
}
public void setSrc(String src) {
	this.src = src;
}
@Override
public String toString() {
	return "Student [studentId=" + studentId + ", name=" + name + ", password=" + password + ", sex=" + sex + ", age="
			+ age + ", teacherId=" + teacherId + ", grade=" + grade + ", clazz=" + clazz + ", titleId=" + titleId
			+ ", src=" + src + "]";
}
public void setTeacherTd(String string) {
	// TODO Auto-generated method stub
	
}
  
  
}
