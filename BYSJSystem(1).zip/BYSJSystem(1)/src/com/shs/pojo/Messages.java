package com.shs.pojo;

public class Messages {
	private String id;
	private String name;
	private String time;
	private String title;
	private String messages;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "messages [id=" + id + ", name=" + name + ", time=" + time + ", title=" + title + ", messages="
				+ messages + "]";
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getMessages() {
		return messages;
	}
	public void setMessages(String messages) {
		this.messages = messages;
	}
	public void setMessages(Messages messages2) {
		// TODO Auto-generated method stub
		
	}

}
