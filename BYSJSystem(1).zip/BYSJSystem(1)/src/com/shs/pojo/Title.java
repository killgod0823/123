package com.shs.pojo;

public class Title {
	private String titleId;
	private String type;
	private String name;
	public String getSrc() {
		return src;
	}
	public void setSrc(String src) {
		this.src = src;
	}
	private String teacherId;
	private String src;
	public String getTitleId() {
		return titleId;
	}
	public void setTitleId(String titleId) {
		this.titleId = titleId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getName() {
		return name;
	}
	public void setName (String name) {
		this.name = name;
	}
	public String getTeacherId() {
		return teacherId;
	}
	public void setTeacherId(String teacherId) {
		this.teacherId = teacherId;
	}
	@Override
	public String toString() {
		return "Title [titleId=" + titleId + ", type=" + type + ", name=" + name + ", teacherId=" + teacherId + ", src="
				+ src + "]";
	}
	

}
