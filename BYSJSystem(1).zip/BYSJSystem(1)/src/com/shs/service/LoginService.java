package com.shs.service;

import java.sql.SQLException;

import com.shs.pojo.Admin;
import com.shs.pojo.Student;
import com.shs.pojo.Teacher;

public interface LoginService {
	  public Admin selectAlIAdmin(String name,String password)throws SQLException;
	  public Student selectAllStudent(String name,String password)throws SQLException;
	  public Teacher  selectAllTeacher(String name,String password)throws SQLException;
	  public int addStudent(Student student)throws SQLException;
	  public int addTeacher(Teacher teacher)throws SQLException;
	     
}
