package com.shs.service;

import java.sql.SQLException;

import com.shs.dao.AdminDao;
import com.shs.dao.AdminDaoImpl;
import com.shs.pojo.Admin;
import com.shs.pojo.Messages;
import com.shs.pojo.Student;
import com.shs.pojo.Teacher;

public class AdminServiceImpl implements AdminService {
       private AdminDao adminDao= new AdminDaoImpl();
		
		@Override
		public int AddTeacher(Teacher teacher) throws SQLException {
			// TODO Auto-generated method stub
			return adminDao.AddTeacher(teacher);
		}
		
		@Override
		public int AddStudent(Student student) throws SQLException {
			// TODO Auto-generated method stub
			return adminDao.AddStudent(student);
		}

		@Override
		public int AddAdmin(Admin admin) throws SQLException {
			// TODO Auto-generated method stub
			return adminDao.AddAdmin(admin);
		}

		@Override
		public int AddMessages(Messages messages) throws SQLException {
			// TODO Auto-generated method stub
			return adminDao.AddMessages(messages);
		}
	
}
