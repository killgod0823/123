package com.shs.service;

import java.sql.SQLException;

import com.shs.pojo.Admin;
import com.shs.pojo.Messages;
import com.shs.pojo.Student;
import com.shs.pojo.Teacher;

public interface AdminService {
	 public int AddStudent(Student student)throws SQLException; 
     public int AddTeacher(Teacher teacher)throws SQLException;
     public int AddAdmin(Admin admin)throws SQLException;
     public int AddMessages(Messages messages)throws SQLException;


}
