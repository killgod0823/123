package com.shs.service;

import java.sql.SQLException;

import com.shs.dao.userDao;
import com.shs.dao.userDaoImpl;
import com.shs.pojo.Admin;
import com.shs.pojo.Student;
import com.shs.pojo.Teacher;

public class LoginServletImpl implements LoginService {
	private userDao userDao = new userDaoImpl();

	@Override
	public Admin selectAlIAdmin(String name, String password) throws SQLException {
		// TODO Auto-generated method stub
		return userDao.selectALlAdmin(name, password);
	}

	@Override
	public Student selectAllStudent(String name, String password) throws SQLException {
		// TODO Auto-generated method stub
		return userDao.selectALlStudent(name, password);
	}

	@Override
	public Teacher selectAllTeacher(String name, String password) throws SQLException {
		// TODO Auto-generated method stub
		return userDao.selectALlTeacher(name, password);
	}

	@Override
	public int addStudent(Student student) throws SQLException {
		// TODO Auto-generated method stub
		return userDao.addStudent(student);
	}

	@Override
	public int addTeacher(Teacher teacher) throws SQLException {
		// TODO Auto-generated method stub
		return userDao.addTeacher(teacher);
	}

}
