package com.shs.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shs.pojo.Teacher;
import com.shs.service.AdminService;
import com.shs.service.AdminServiceImpl;

/**
 * Servlet implementation class AddTeacher
 */
@WebServlet("/AddTeacher")
public class AddTeacher extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private AdminService adminService =new AdminServiceImpl();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddTeacher() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String teacherId=request.getParameter("teacherId");
		String tname=request.getParameter("tname");
		String password=request.getParameter("password");
		String tsex=request.getParameter("tsex");
		String tage=request.getParameter("tage");
		String tdept=request.getParameter("tdept");
		String tel=request.getParameter("tel");
		String QQ=request.getParameter("QQ");
		String proferssional=request.getParameter("professional");
		 
		
		//创建对象用来接收后端传送的数据
		Teacher teacher=new Teacher();
		teacher.setTeacherId(teacherId);
		teacher.setTname(tname);
		teacher.setPassword(password);
		teacher.setTsex(tsex);
		teacher.setTage(tage);
		teacher.setTdept(tdept);
		teacher.setTel(tel);
		teacher.setQQ(QQ);
		teacher.setProfessional(proferssional);
		
		try {
			if(adminService.AddTeacher(teacher)==1) {
				response.getWriter().write("success");
			}
			else {
				response.getWriter().write("fail");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		
}
