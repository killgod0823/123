package com.shs.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shs.dao.StudentDao;
import com.shs.dao.StudentDaoImpl;

/**
 * Servlet implementation class choose
 */
@WebServlet("/choose")
public class choose extends HttpServlet {
	private static final long serialVersionUID = 1L;
       private StudentDao studentDao=new StudentDaoImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public choose() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	     request.setCharacterEncoding("utf-8");
	     response.setCharacterEncoding("utf-8");
	     response.setContentType("text/html;charset=utf-8");
	     
	     //接收前端传递过来的参数
	     String studentId=request.getParameter("studentId");
	     String teacherId=request.getParameter("teacherId");
	     String title=request.getParameter("titleId");
	     //titleId为int型
	     int titleId=Integer.parseInt(title);
	    try {
	    	//调用dao层
	    	int a=studentDao.ifhasTitle(studentId);
	    	//判断当前是否有选题
			if( a!=0) {
				response.getWriter().write("选题失败！您当前已有选题："+a);
			}else {
				//暂无选题 提示选题成功
				int b=studentDao.chooseTitle(studentId, teacherId, titleId);
				
				if (b==1) {
					response.getWriter().write("恭喜你选题成功！："+titleId);
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	     
	}
}
