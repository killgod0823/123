package com.shs.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shs.dao.StudentDao;
import com.shs.dao.StudentDaoImpl;
import com.shs.pojo.Title;

/**
 * Servlet implementation class submitMyProject
 */
@WebServlet("/submitMyProject")
public class submitMyProject extends HttpServlet {
	private static final long serialVersionUID = 1L;
       private StudentDao studentDao=new StudentDaoImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public submitMyProject() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String studentId=request.getParameter("studentId");
		String src=request.getParameter("src");
	
		
		try {
			/* int a=teacherDao.addTitle(title); */
			int a=studentDao.submitMyProject(studentId, src);
		
			if (a==1) {
				
				response.getWriter().write("success");
			}else {
				response.getWriter().write("fail");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
