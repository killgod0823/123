package com.shs.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.shs.pojo.Admin;
import com.shs.pojo.Student;
import com.shs.pojo.Teacher;
import com.shs.service.LoginService;
import com.shs.service.LoginServletImpl;

/**
 * Servlet implementation class CheckLoginServlet
 */
@WebServlet("/CheckLoginServlet")
public class CheckLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private LoginService loginService=new LoginServletImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CheckLoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String name=request.getParameter("name");
		String password=request.getParameter("password");
		String entity=request.getParameter("entity");
		if (entity.equals("管理员")) {
			Admin admin;
			try {
				admin=loginService.selectAlIAdmin(name, password);
				
				System.out.println(admin);
				if(admin!=null) {
					HttpSession session =request.getSession();
					//把当前输入的信息放到session域中，以便jsp页面使用
					session.setAttribute("admin", admin);
					//用户登录成功返回一个success给前端
					response.getWriter().write("success");
				}else {
					response.getWriter().write("fail");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		     
		} else if(entity.equals("学生")){
			Student student;
			try {
				student=loginService.selectAllStudent(name, password);
				System.out.println(student);
				if(student!=null) {
					HttpSession session =request.getSession();
					//把当前输入的信息放到session域中，以便jsp页面使用
					session.setAttribute("student", student);
					response.getWriter().write("success");
				}else {
					response.getWriter().write("fail");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}else if(entity.equals("教师")) {
			Teacher teacher;
			try {
				teacher=loginService.selectAllTeacher(name, password);
				
				if(teacher!=null) {
					System.out.println(teacher);
					HttpSession session =request.getSession();
					//把当前输入的信息放到session域中，以便jsp页面使用
					session.setAttribute("teacher", teacher);
					response.getWriter().write("success");
				}else {
					response.getWriter().write("fail");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
