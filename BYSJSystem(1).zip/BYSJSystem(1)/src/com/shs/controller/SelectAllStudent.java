package com.shs.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSONObject;
import com.shs.dao.userDao;
import com.shs.dao.userDaoImpl;
import com.shs.pojo.Student;
import com.shs.pojo.Vo;




/**
 * Servlet implementation class SelectAllStudent
 */
@WebServlet("/SelectAllStudent")
public class SelectAllStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SelectAllStudent() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		/*
		 * System.out.println(pageStr); System.out.println(limitStr);
		 */
	userDao userDao = new userDaoImpl();
		List<Object> list = null;
		try {
			list = userDao.selectStudentList();

			response.setContentType("text/html;charset=utf-8");
			Vo vo=new Vo();
			vo.setCode(0);
			vo.setMsg("success");
			vo.setCount(list.size());
			vo.setData(list);
			response.getWriter().write(JSONObject.toJSON(vo).toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
