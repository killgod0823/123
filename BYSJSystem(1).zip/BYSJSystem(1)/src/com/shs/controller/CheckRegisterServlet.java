package com.shs.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shs.pojo.Student;
import com.shs.pojo.Teacher;
import com.shs.service.LoginService;
import com.shs.service.LoginServletImpl;

/**
 * Servlet implementation class CheckZhuCeServlet
 */
@WebServlet("/CheckRegisterServlet")
public class CheckRegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private LoginService loginService=new LoginServletImpl();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CheckRegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name=request.getParameter("name");
		String password=request.getParameter("password");
		String id=request.getParameter("id");
		String entity=request.getParameter("entity");
//		System.out.println(name+":"+password+":"+id+":"+entity);
		Student student;
		Teacher teacher;
		if(entity.equals("学生")) {
			
			try {
				student=loginService.selectAllStudent(name, password);
				if(student==null) {
					//
					student=new Student();
					
					student.setStudentId(id);
					student.setName(name);
					student.setPassword(password);
					int s=loginService.addStudent(student);
					if(s==1) {
						response.getWriter().write("success");
					}else {
						response.getWriter().write("fail");
					}
				}else {
					response.getWriter().write("fail");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if(entity.equals("教师")){
			try {
				teacher=loginService.selectAllTeacher(name, password);
				if(teacher==null) {
					//
					teacher=new Teacher();
					
					teacher.setTeacherId(id);
				    teacher.setTname(name);
					teacher.setPassword(password);
					int s=loginService.addTeacher(teacher);
					if(s==1) {
						response.getWriter().write("success");
					}else {
						response.getWriter().write("fail");
					}
				}else {
					response.getWriter().write("fail");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
