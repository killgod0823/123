package com.shs.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shs.dao.editDao;
import com.shs.dao.editDaoImpl;
import com.shs.pojo.Student;
import com.shs.pojo.Teacher;

/**
 * Servlet implementation class EditStuent
 */
@WebServlet("/EditStudent")
public class EditStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	/**
     * @see HttpServlet#HttpServlet()
     */
    public EditStudent() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 request.setCharacterEncoding("utf-8");
		  response.setCharacterEncoding("utf-8");
		  response.setContentType("text/html;charset=utf-8");
		  String studentId=request.getParameter("studentId");
		  String name=request.getParameter("name");
		  String age=request.getParameter("age");
		  String sex=request.getParameter("sex");
		  String teacherId=request.getParameter("teacherId");
		  String grade=request.getParameter("grade");
		  String clazz=request.getParameter("clazz");
		  String titleId=request.getParameter("titleId");
		  
		 
		  int titleId1=Integer.parseInt(titleId);
		  int grade1=Integer.parseInt(grade);
		  int age1=Integer.parseInt(age);
		  Student student=new Student();
		  student.setStudentId(studentId);
		  student.setAge(age1);
		  student.setClazz(clazz);
		  student.setGrade(grade1);
		  student.setName(name);
		  student.setSex(sex);
		  student.setTeacherId(teacherId);
		  student.setTitleId(titleId1);
		  
		  editDao editDao=new editDaoImpl();
		  try {//判断是否修改成功
			if(editDao.EditStudent(student)==1) {
				  response.getWriter().write("success");
			  }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
