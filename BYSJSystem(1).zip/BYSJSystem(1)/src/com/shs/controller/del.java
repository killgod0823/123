package com.shs.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shs.dao.StudentDao;
import com.shs.dao.StudentDaoImpl;

/**
 * Servlet implementation class del
 */
@WebServlet("/del")
public class del extends HttpServlet {
	private static final long serialVersionUID = 1L;
       private StudentDao studentDao=new StudentDaoImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public del() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
	     response.setCharacterEncoding("utf-8");
	     response.setContentType("text/html;charset=utf-8");
	     
	     String studentId=request.getParameter("studentId");
	     String teacherId=request.getParameter("teacherId");
	     String title=request.getParameter("titleId");
	     int titleId=Integer.parseInt(title);
	     try {
			int a=studentDao.ifhasTitle(studentId);
			if (a!=0) {
				//已有选题，
				if (a==titleId) {
					//执行退选操作，提示尽快重新选择
					int b=studentDao.delTitle(studentId, teacherId, titleId);
					if (b==1) {
						response.getWriter().write("退选成功！！请尽快重新选择");
					}
					
				}else {
					//提示，当前您的选题不是这个，无效点击
					response.getWriter().write("当前您的选题不是这个，无效点击");
				}
			}else {
				//没有选题 提示先进行选题操作
				response.getWriter().write("您当前还未选题，请先选题");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     
	}

}
