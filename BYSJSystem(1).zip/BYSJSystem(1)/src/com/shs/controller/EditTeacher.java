package com.shs.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shs.dao.editDao;
import com.shs.dao.editDaoImpl;
import com.shs.pojo.Teacher;

/**
 * Servlet implementation class EditTeacher
 */
@WebServlet("/EditTeacher")
public class EditTeacher extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditTeacher() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	   doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	  request.setCharacterEncoding("utf-8");
	  response.setCharacterEncoding("utf-8");
	  response.setContentType("text/html;charset=utf-8");
	  
	  String teacherId=request.getParameter("teacherId");
	  String tname=request.getParameter("tname");
	  String tage=request.getParameter("tage");
	  String tsex=request.getParameter("tsex");
	  String tdept=request.getParameter("tdept");
	  
	  String tel=request.getParameter("tel");
	  String QQ=request.getParameter("QQ");
	  String professional=request.getParameter("professional");
	  //转换年龄的类型，数据库中为int 型
	  
	  Teacher teacher = new Teacher();
	  teacher.setTeacherId(teacherId);
	  teacher.setTname(tname);
	  teacher.setTage(tage);
	  teacher.setTsex(tsex);
	  teacher.setTel(tel);
	  teacher.setTdept(tdept);
	  teacher.setQQ(QQ);
	  teacher.setProfessional(professional);
	  
	  editDao editDao = new editDaoImpl();
	  try {
		if (editDao.EditTeacher(teacher)==1) {
			response.getWriter().write("success");
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
			  
	  
	 
	}

}
