/*
 Navicat Premium Data Transfer

 Source Server         : 123.57.134.242
 Source Server Type    : MySQL
 Source Server Version : 80020
 Source Host           : 123.57.134.242:3306
 Source Schema         : g_design

 Target Server Type    : MySQL
 Target Server Version : 80020
 File Encoding         : 65001

 Date: 24/04/2023 21:15:13
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for s_admin
-- ----------------------------
DROP TABLE IF EXISTS `s_admin`;
CREATE TABLE `s_admin`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `name` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `password` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of s_admin
-- ----------------------------
INSERT INTO `s_admin` VALUES (1, 'admin', '1');

-- ----------------------------
-- Table structure for s_student
-- ----------------------------
DROP TABLE IF EXISTS `s_student`;
CREATE TABLE `s_student`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `studentId` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 25 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of s_student
-- ----------------------------
INSERT INTO `s_student` VALUES (1, '宋先慧', '1', '318102020133');
INSERT INTO `s_student` VALUES (2, '1', '1', '1');
INSERT INTO `s_student` VALUES (10, '2', '2', '2');
INSERT INTO `s_student` VALUES (11, '张果果', '11', '11');
INSERT INTO `s_student` VALUES (24, '宋先慧2', '1', '33');

-- ----------------------------
-- Table structure for s_teacher
-- ----------------------------
DROP TABLE IF EXISTS `s_teacher`;
CREATE TABLE `s_teacher`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `teacherId` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of s_teacher
-- ----------------------------
INSERT INTO `s_teacher` VALUES (1, '张三', '1', '1');
INSERT INTO `s_teacher` VALUES (8, '222', '1', '111');
INSERT INTO `s_teacher` VALUES (9, '李四', '1', '12345678');

-- ----------------------------
-- Table structure for studentinfo
-- ----------------------------
DROP TABLE IF EXISTS `studentinfo`;
CREATE TABLE `studentinfo`  (
  `studentId` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `sex` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `age` int(0) NULL DEFAULT NULL,
  `teacherId` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `grade` int(0) NULL DEFAULT NULL,
  `clazz` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `titleId` int(0) NULL DEFAULT NULL,
  `src` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`studentId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of studentinfo
-- ----------------------------
INSERT INTO `studentinfo` VALUES ('1', '1', '男', 1, '1', 99, 'java4', 1, NULL);
INSERT INTO `studentinfo` VALUES ('11', '张果果', '男', 1, '1', 100, 'java2', 1, NULL);
INSERT INTO `studentinfo` VALUES ('2', '2', '男', 1, '1', 0, 'java1', 1, NULL);
INSERT INTO `studentinfo` VALUES ('2147483647', 'zhangsan', '男', 28, '1', 0, 'undefined', 1, NULL);
INSERT INTO `studentinfo` VALUES ('318102020133', '宋先慧', '男', 22, '1', 0, 'java1', 2, './/upload/03.程序执行结构.docx');
INSERT INTO `studentinfo` VALUES ('33', '宋先慧2', '男', 11, '2', 0, 'Java1', 2, NULL);

-- ----------------------------
-- Table structure for teacherinfo
-- ----------------------------
DROP TABLE IF EXISTS `teacherinfo`;
CREATE TABLE `teacherinfo`  (
  `teacherId` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `tname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `tage` int(0) NULL DEFAULT NULL,
  `tsex` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `tdept` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `tel` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `QQ` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `professional` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`teacherId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of teacherinfo
-- ----------------------------
INSERT INTO `teacherinfo` VALUES ('1', '张三feng', 33, '男', '计算机', '121', '121', '教授');
INSERT INTO `teacherinfo` VALUES ('10', '小红', 23, '女', '计算机', '1', '1', '教授');
INSERT INTO `teacherinfo` VALUES ('11', '小红', 23, '女', '计算机', '1', '1', '教授');
INSERT INTO `teacherinfo` VALUES ('111', '222', 22, '女', '计算机', '1', '1', NULL);
INSERT INTO `teacherinfo` VALUES ('12', '小红', 23, '女', '计算机', '1', '1', '教授');
INSERT INTO `teacherinfo` VALUES ('12345678', '李四', 22, '男', '计算机', '1', '1', NULL);
INSERT INTO `teacherinfo` VALUES ('13', '小红', 23, '女', '计算机', '1', '1', '教授');
INSERT INTO `teacherinfo` VALUES ('14', '小红', 23, '女', '计算机', '1', '1', '教授');
INSERT INTO `teacherinfo` VALUES ('15', '1', 23, '女', '计算机', '1', '1', '副教授');
INSERT INTO `teacherinfo` VALUES ('3', '王五', 32, '男', '计算机', '1212', '121', '讲师');
INSERT INTO `teacherinfo` VALUES ('4', '小红', 23, '女', '计算机', '1', '1', '教授');
INSERT INTO `teacherinfo` VALUES ('5', '小红', 23, '女', '计算机', '1', '1', '教授');
INSERT INTO `teacherinfo` VALUES ('6', '小红', 23, '女', '计算机', '1', '1', '教授');
INSERT INTO `teacherinfo` VALUES ('7', '小红', 23, '女', '计算机', '1', '1', '教授');

-- ----------------------------
-- Table structure for titleinfo
-- ----------------------------
DROP TABLE IF EXISTS `titleinfo`;
CREATE TABLE `titleinfo`  (
  `titleId` int(0) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `teacherId` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `src` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`titleId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 16 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of titleinfo
-- ----------------------------
INSERT INTO `titleinfo` VALUES (1, '开发', '火车票销售系统', '1', NULL);
INSERT INTO `titleinfo` VALUES (2, '设计', '原型设计方案', '1', NULL);
INSERT INTO `titleinfo` VALUES (3, '开发', '系统开发方式', '1', NULL);
INSERT INTO `titleinfo` VALUES (4, '开发', '数据库优化', '1', NULL);
INSERT INTO `titleinfo` VALUES (5, 'mysql', '如何高并发写库', '1', NULL);
INSERT INTO `titleinfo` VALUES (14, '开发', '宋先慧2', '1', './/upload/《计算机组成原理》教材电子版.pdf');
INSERT INTO `titleinfo` VALUES (15, '开发', '牙刷', '1', './/upload/7.IO流.docx');

SET FOREIGN_KEY_CHECKS = 1;
